import os
import cv2
import torch
import numpy as np
from model import UNetLext
from args import get_args

# SETTINGS
args = get_args()
CSV_DIR = args.csv_dir
PRED_DIR = 'predictions/'  # folder to save predictions (optional)
MODEL_PATH = 'session/best_model.pth'  # replace with your trained model path

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# LOAD TEST IMAGES
import pandas as pd
test_csv = os.path.join(CSV_DIR, 'test.csv')
test_df = pd.read_csv(test_csv)

test_images = test_df['xrays'].tolist()

# LOAD MODEL
model = UNetLext(input_channels=1, output_channels=1)
model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
model.to(DEVICE)
model.eval()
print("Model loaded successfully!")

# PREDICTION FUNCTION
def preprocess_image(path):
    xray = cv2.imread(path, cv2.IMREAD_GRAYSCALE).astype(np.float32) / 255.0
    xray = xray.reshape(1, 1, *xray.shape)  # (1,1,H,W)
    return torch.tensor(xray, device=DEVICE)

def postprocess_mask(logits):
    probs = torch.sigmoid(logits)
    mask = (probs > 0.5).cpu().numpy()[0,0] * 255  # 0-255
    return mask.astype(np.uint8)

# SHOW IMAGES LIVE
for img_path in test_images:
    xray_tensor = preprocess_image(img_path)
    with torch.no_grad():
        pred_logits = model(xray_tensor)
        mask = postprocess_mask(pred_logits)

    # Read original X-ray for visualization
    xray = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    # Resize mask to match X-ray (just in case)
    mask_resized = cv2.resize(mask, (xray.shape[1], xray.shape[0]))

    # Overlay mask on X-ray
    overlay = cv2.addWeighted(xray, 0.7, mask_resized, 0.3, 0)

    # Stack original and overlay side by side
    combined = np.hstack([xray, overlay])

    # Show window
    cv2.imshow("X-ray | Predicted Mask Overlay", combined)
    key = cv2.waitKey(0)  # press any key to go to next image
    if key == 27:  # ESC key to exit
        break

cv2.destroyAllWindows()


